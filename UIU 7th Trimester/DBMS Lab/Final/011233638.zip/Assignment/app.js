const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");

const app = express();

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "todo_db",
});

app.get("/", (req, res) => {
  db.query("SELECT * FROM tasks", (err, results) => {
    if (err) throw err;
    res.render("index", { tasks: results });
  });
});

app.post("/add", (req, res) => {
  const { name, due } = req.body;
  const sql = "INSERT INTO tasks (task_name, due_time) VALUES (?, ?)";

  db.query(sql, [name, due], (err) => {
    if (err) throw err;
    res.redirect("/");
  });
});

app.post("/remove", (req, res) => {
  const { id } = req.body;

  db.query("DELETE FROM tasks WHERE id = ?", [id], (err) => {
    if (err) throw err;
    res.redirect("/");
  });
});

app.listen(3000, () => {
  console.log("Server started on port 3000");
});
